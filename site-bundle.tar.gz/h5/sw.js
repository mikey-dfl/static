/* 易家佳 PWA Service Worker
 * 功能:
 *  1. 应用外壳缓存 (断网也能打开界面)
 *  2. 静态资源缓存优先
 *  3. 接口/WebSocket 一律走网络(不缓存, 保证消息实时)
 */
const VERSION = 'yjj-github-h5-v1';
const SHELL_CACHE = VERSION + '-shell';
const ASSET_CACHE = VERSION + '-assets';

const SHELL_FILES = [
  '/static/h5/',
  '/static/h5/index.html',
  '/static/h5/pwa/icon-192.png',
  '/static/h5/pwa/icon-512.png'
];

// 安装: 预缓存外壳
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(SHELL_FILES).catch(() => {}))
  );
  self.skipWaiting();
});

// 激活: 清理旧版本缓存
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k.startsWith('yjj-github-h5-') && !k.startsWith(VERSION))
          .map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// 请求拦截
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // 只处理 GET
  if (req.method !== 'GET') return;

  // 跨域、接口、文件上传下载一律不缓存
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') ||
      url.pathname.startsWith('/adm/') ||
      url.pathname.startsWith('/im') ||
      url.pathname.startsWith('/file/')) {
    return;
  }

  // 静态资源: 缓存优先, 后台更新
  if (/\.(js|css|png|jpg|jpeg|gif|svg|woff2?|ttf|otf|ico|webp)$/i.test(url.pathname)) {
    event.respondWith(
      caches.match(req).then((hit) => {
        if (hit) return hit;
        return fetch(req).then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(ASSET_CACHE).then((c) => c.put(req, copy)).catch(() => {});
          }
          return res;
        }).catch(() => hit);
      })
    );
    return;
  }

  // 页面导航: 网络优先, 失败回退缓存
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL_CACHE).then((c) => c.put(req, copy)).catch(() => {});
          return res;
        })
        .catch(() => caches.match(req).then((hit) => hit || caches.match('/static/h5/index.html')))
    );
  }
});

// 收到后台推送(如接入 Web Push 时使用)
self.addEventListener('push', (event) => {
  let data = { title: '易家佳', body: '您有一条新消息' };
  try {
    if (event.data) data = Object.assign(data, event.data.json());
  } catch (e) {}
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/static/h5/pwa/icon-192.png',
      badge: '/static/h5/pwa/icon-96.png',
      vibrate: [200, 100, 200],
      tag: 'yjj-message',
      renotify: true,
      data: { url: '/static/h5/#/pages/chat/chat' }
    })
  );
});

// 点击通知: 聚焦或打开应用
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || '/static/h5/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if (client.url.includes('/static/h5/') && 'focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow(target);
    })
  );
});
