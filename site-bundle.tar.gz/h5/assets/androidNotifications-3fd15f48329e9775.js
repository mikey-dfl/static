// The Android host transfers a MessagePort only to its trusted top-level H5 page.
// A normal browser has no port, so notification calls are harmless no-ops.
const HANDSHAKE = 'yijiajia-notifications';

function positiveId(value) {
	if (typeof value !== 'number' && typeof value !== 'string') return null;
	const text = String(value);
	return /^[1-9]\d*$/.test(text) && Number.isSafeInteger(Number(text)) ? text : null;
}

function chatTarget(value) {
	if (!value || !['PRIVATE', 'GROUP'].includes(value.chatType)) return null;
	const targetId = positiveId(value.targetId);
	return targetId ? { chatType: value.chatType, targetId } : null;
}

export function createAndroidNotifications(browserWindow) {
	let port = null;
	let visible = true;
	let active = false;
	let sessionKnown = false;
	let ready = false;
	let acceptOpen = true;
	let pendingOpen = null;
	let openHandler = null;
	const sentKeys = new Set();

	function send(message) {
		if (!port) return false;
		try {
			port.postMessage(JSON.stringify(message));
			return true;
		} catch (_) {
			return false;
		}
	}

	function flushOpen() {
		if (!active || !ready || !pendingOpen || !openHandler) return;
		const target = pendingOpen;
		pendingOpen = null;
		openHandler(target);
	}

	function sendSession() {
		const message = { type: 'session', active };
		// Initial hydration is different from an explicit logout or failed login.
		if (sessionKnown && !active) message.clear = true;
		send(message);
	}

	function receive(event) {
		if (typeof event.data !== 'string') return;
		let message;
		try {
			message = JSON.parse(event.data);
		} catch (_) {
			return;
		}
		if (message && message.type === 'visibility' && typeof message.visible === 'boolean') {
			visible = message.visible;
			return;
		}
		if (!acceptOpen) return;
		const target = message && message.type === 'open' && chatTarget(message);
		if (!target) return;
		pendingOpen = target;
		flushOpen();
	}

	if (browserWindow && typeof browserWindow.addEventListener === 'function') {
		browserWindow.addEventListener('message', (event) => {
			if (event.data !== HANDSHAKE || !event.ports || event.ports.length !== 1) return;
			// Native messages have no source window; ignore transfers from child frames.
			if (event.source && event.source !== browserWindow) return;
			if (port) {
				port.onmessage = null;
				port.close();
			}
			port = event.ports[0];
			visible = true;
			port.onmessage = receive;
			port.start();
			sendSession();
		});
	}

	return {
		isBackground() {
			return port !== null && !visible;
		},
		onOpen(handler) {
			openHandler = handler;
			flushOpen();
		},
		setSession(value) {
			sessionKnown = true;
			active = value === true;
			acceptOpen = active;
			if (!active) {
				ready = false;
				pendingOpen = null;
				sentKeys.clear();
			}
			sendSession();
			flushOpen();
		},
		setReady(value) {
			ready = value === true;
			flushOpen();
		},
		notify(message) {
			if (!active || !port || !message) return false;
			const target = chatTarget(message);
			const messageId = positiveId(message.messageId);
			if (!target || !messageId || !Number.isInteger(message.messageType) ||
				message.messageType < 0 || message.messageType >= 10 ||
				typeof message.content !== 'string' || !message.content) return false;
			const key = `${target.chatType}:${target.targetId}:${messageId}`;
			if (sentKeys.has(key)) return false;
			if (!send({
				type: 'notify', key, title: String(message.title || '').slice(0, 80),
				content: message.content.slice(0, 240), ...target
			})) return false;
			sentKeys.add(key);
			if (sentKeys.size > 256) sentKeys.delete(sentKeys.values().next().value);
			return true;
		}
	};
}

export default createAndroidNotifications(typeof window === 'undefined' ? null : window);
