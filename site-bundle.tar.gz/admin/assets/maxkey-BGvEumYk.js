const a="/static/admin/assets/maxkey-BQHOSwiS.svg";export{a as default};
